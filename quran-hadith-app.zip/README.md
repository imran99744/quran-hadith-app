# Quran Hadith API

A comprehensive FastAPI backend for Quran and Hadith application with PostgreSQL database.

## Features

- **Quran Data Management**
  - Complete Surah and Ayah database
  - Juz (section) support
  - Arabic text with English translations
  - Search functionality in Arabic and English
  - Random verse functionality

- **Hadith Data Management**
  - Multiple collections (Sahih Bukhari, Sahih Muslim, etc.)
  - Book and chapter organization
  - Arabic text with English translations
  - Authentication grading (Sahih, Hasan, Da'if)
  - Advanced search and filtering

- **User Management**
  - JWT-based authentication
  - User registration and login
  - Admin user support
  - Protected endpoints

- **API Features**
  - RESTful API design
  - Automatic API documentation (OpenAPI/Swagger)
  - Pagination support
  - Search and filtering
  - CORS support
  - Health checks

## Technology Stack

- **Backend**: FastAPI (Python 3.11)
- **Database**: PostgreSQL
- **ORM**: SQLAlchemy
- **Authentication**: JWT (JSON Web Tokens)
- **Documentation**: OpenAPI/Swagger
- **Containerization**: Docker & Docker Compose
- **Testing**: Pytest

## Quick Start

### Using Docker (Recommended)

1. Clone the repository:
```bash
git clone <repository-url>
cd quran-hadith-app
```

2. Start the application:
```bash
docker-compose up --build
```

3. Access the API:
- API: http://localhost:8000
- Documentation: http://localhost:8000/docs
- Health Check: http://localhost:8000/health

### Manual Setup

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Set up PostgreSQL database and update `.env`:
```bash
cp .env.example .env
# Edit .env with your database credentials
```

3. Run database migrations/seed:
```bash
python -m app.db.seed
```

4. Start the application:
```bash
uvicorn main:app --reload
```

## API Endpoints

### Authentication
- `POST /api/v1/auth/register` - Register new user
- `POST /api/v1/auth/login` - User login
- `GET /api/v1/auth/me` - Get current user info

### Quran
- `GET /api/v1/quran/surahs` - List all surahs
- `GET /api/v1/quran/surahs/{surah_number}` - Get specific surah
- `GET /api/v1/quran/surahs/{surah_number}/ayahs` - Get surah with all ayahs
- `GET /api/v1/quran/surahs/{surah_number}/ayahs/{ayah_number}` - Get specific ayah
- `GET /api/v1/quran/juzs` - List all juzs
- `GET /api/v1/quran/juzs/{juz_number}` - Get specific juz
- `GET /api/v1/quran/juzs/{juz_number}/ayahs` - Get ayahs in juz
- `GET /api/v1/quran/search` - Search Quran
- `GET /api/v1/quran/random-ayah` - Get random ayah

### Hadith
- `GET /api/v1/hadith/collections` - List all collections
- `GET /api/v1/hadith/collections/{collection_id}` - Get specific collection
- `GET /api/v1/hadith/collections/{collection_id}/books` - Get books in collection
- `GET /api/v1/hadith/collections/{collection_id}/hadiths` - Get hadiths in collection
- `GET /api/v1/hadith/books/{book_id}` - Get specific book
- `GET /api/v1/hadith/books/{book_id}/hadiths` - Get hadiths in book
- `GET /api/v1/hadith/hadiths/{hadith_id}` - Get specific hadith
- `GET /api/v1/hadith/chapters/{chapter_id}` - Get specific chapter
- `GET /api/v1/hadith/chapters/{chapter_id}/hadiths` - Get hadiths in chapter
- `GET /api/v1/hadith/search` - Search hadiths
- `GET /api/v1/hadith/random-hadith` - Get random hadith

## Sample Data

The application comes with sample data including:
- **Admin User**: `admin` / `admin123`
- **Quran Data**: 3 Surahs with complete Al-Fatihah ayahs
- **Hadith Data**: Sahih Bukhari and Sahih Muslim collections with sample hadiths

To populate the database:
```bash
python -m app.db.seed
```

## API Documentation

Once the application is running, visit:
- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

## Testing

Run tests with:
```bash
pytest
```

## Environment Variables

Key environment variables in `.env`:
```bash
DATABASE_URL=postgresql://username:password@localhost:5432/quran_hadith_db
SECRET_KEY=your-secret-key-here
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30
APP_NAME="Quran Hadith API"
APP_VERSION="1.0.0"
DEBUG=True
```

## Database Schema

### Tables
- `users` - User authentication and management
- `surahs` - Quran chapters
- `ayahs` - Quran verses
- `juzs` - Quran sections
- `collections` - Hadith collections (Bukhari, Muslim, etc.)
- `books` - Books within collections
- `hadiths` - Individual hadith records
- `chapters` - Chapters within books

## Security Features

- Password hashing with bcrypt
- JWT token authentication
- CORS configuration
- Input validation with Pydantic
- SQL injection protection via SQLAlchemy ORM

## Development

### Adding New Data
1. Add records to database via API or direct database operations
2. Use the seed script pattern for bulk data import
3. Follow the existing schema patterns

### API Extensions
- Add new routes in `app/api/routes/`
- Follow the existing patterns for authentication and database access
- Update schemas in `app/schemas/`

## Production Deployment

1. Update environment variables
2. Use a production-ready PostgreSQL instance
3. Configure proper CORS origins
4. Set up reverse proxy (nginx)
5. Implement SSL/TLS
6. Set up monitoring and logging

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Submit a pull request

## License

This project is open source and available under the MIT License.
